create definer = root@`%` view viewUSA as
select `learning`.`weather`.`city`      AS `city`,
       `learning`.`weather`.`lattitude` AS `lattitude`,
       `learning`.`weather`.`longitude` AS `longitude`,
       `learning`.`weather`.`temp`      AS `temp`,
       `learning`.`weather`.`country`   AS `country`
from `learning`.`weather`
where (`learning`.`weather`.`country` = 'USA');

