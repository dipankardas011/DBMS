create
    definer = root@localhost procedure insert_data_student1(IN student_name varchar(50), IN email varchar(50), IN group_id int)
begin

     if not exists(select email from student where email="email")
     then
         insert into student(student_name,email,group_id) values (student_name,email,group_id);
     else
          select 'all reday exists';

     end if;
 end;

